function solve() {
   let inputMessage = document.getElementById('chat_input'); // get VALUE of "chat_input" message currently in the text field
   const newDiv = document.createElement('div');       // Create new <div> -> assigned to newDiv variable
   newDiv.setAttribute("class", "message my-message"); // Set "class" attribute and "className" to div -> <div class="message my-message">
   newDiv.innerText = inputMessage.value;                    // Assign inner text value of input message to new <div>
   const chatMessages = document.getElementById('chat_messages');  // Get parent <div> "chat_messages"
   const send = document.getElementById('send');       // Get "send" <button> element ById
   console.log(inputMessage, "script ran!")
   // Add click event to the "send" button which holds a function which appends newDiv to
   send.addEventListener('click', function() {
      chatMessages.appendChild(newDiv); 
      newDiv.innerText = inputMessage.value;
      inputMessage.value = '';
      return;
   }); 
}