Ron, 

Whoever is grading this should look at only the following files.

- index.html
- /scripts/workshop.js

That's where my code is at.

In regards of the functionality of the workshop page, I did the best I can
to make the function work for both the consultations functionality and the 
slider.

All other files and folders that are in there are necessary for the workshop page 
to work.

Due to time constraints, I'm submitting what I have.

Thanks for your understanding.

Sidney Juachon