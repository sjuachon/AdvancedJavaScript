function print() {
    const sliderSection = document.querySelector(".slider");
    const newDiv = document.createElement("div");
    newDiv.class = "test";
    sliderSection.appendChild(newDiv);
    const sliderDiv = sliderSection.lastElementChild;

    const imageArr = [
        "djangoprogrammi_thumbnail.png",
        "html-css-fundaments.jpg",
        "js-fundamentals.jpg",
        "programming-fundamentals.png",
        "pt-fund.png",
    ];

    for (let i = 0; i < imageArr.length; i++) {
        const newDiv = document.createElement("div");
        const newImg = document.createElement("img");
        newImg.src = `./images/${imageArr[i]}`;
        newDiv.appendChild(newImg);
        sliderDiv.appendChild(newDiv);
    }
}

function slickSlider() {}
