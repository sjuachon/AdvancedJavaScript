function bookIt(){
    // Define variables to get    

    let selectEl = document.getElementById("lecturer");
       
    let boxFooterDiv = document.getElementsByClassName('box-footer');
    let spanCounter = document.getElementById('TotalConsultations');

    // define a button variable
    let button = document.getElementById("bookHourBtn");
    console.log(button);

 
            
    // get values from options
    let lecturerSelect = document.getElementById("lecturer");
    let lecturerOption = document.querySelectorAll("option");
    console.log(lecturerSelect, lecturerOption);
    for(let i = 4; i < lecturerOption.length; i++){
        // lecturerSelect.appendChild(newSpan);
        lecturerSelect.appendChild(lecturerOption[i]);
    }
    
    
    
    console.log(spanCounter);
    
    // footer
    let divFooter = document.getElementsByClassName("box-footer");
    
    //let newSpan = document.createElement("span")
    let affectedUl = document.getElementById("affectedUl");        
    const newLi = document.createElement("li");
    const newSpan = document.createElement('span');
    const newI = document.createElement('i');
    newI.setAttribute("id", "mychevron");
    
    // when the user clicks the send button
    button.addEventListener('click', function() {
        // relationships with box-body class
        console.log("Button clicked.");
        
        
        // create new consultation schedule based on boxBodyDiv
        // Enter Date and Time
        const newDate = document.getElementById('date');


        if(lecturerSelect.value === "Patrick") {
            newSpan.innerHTML += "<p><span>Patrick - " + newDate.value + " - 03:30</span>" + "<i class=\"fas fa-chevron-circle-right\" id = \"mychevron\"></i>";
        } else if(lecturerSelect.value === "Anar") {
            newSpan.innerHTML += "<p><span>Anar - " + newDate.value + " - 03:15</span>" + "<i class=\"fas fa-chevron-circle-right\" id = \"mychevron\"></i>";
        } else if (lecturerSelect.value === "Simeon") {
            newSpan.innerHTML += "<p><span>Simeon - " + newDate.value + " - 03:30</span>" +  "<i class=\"fas fa-chevron-circle-right\" id = \"mychevron\"></i>";
        } else if(lecturerSelect.value === "Katoshki") {
            newSpan.innerHTML += "<p><span>Katoshki - " + newDate.value + " - 03:30</span>" + "<i class=\"fas fa-chevron-circle-right\" id = \"mychevron\"></i>";
        } else if(lecturerSelect.value === "Ron") {
            newSpan.innerHTML += "<p><span>Ron - " + newDate.value + " - 03:20</span>" + "<i class=\"fas fa-chevron-circle-right\" id = \"mychevron\"></i>";
        }
     
        // span.innerHTML = optionEls.innerHTML;
        affectedUl.appendChild(newLi);
            console.log(newLi);
        newLi.appendChild(newSpan)
        
        newLi.appendChild(newI);
            console.log(newI);
        console.log(newSpan.innerHTML);
        console.log(spanCounter.innerHTML);
        
        Number(spanCounter.innerHTML);
        spanCounter.innerHTML++
        console.log(spanCounter.innerHTML);
        return;
    });
}